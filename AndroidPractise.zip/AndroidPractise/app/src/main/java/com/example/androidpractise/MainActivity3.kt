package com.example.androidpractise

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.activity_main3.*

class MainActivity3 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main3)
/*
        var status =if(editTextPersonName.text.toString().equals("Android") &&editTextPassword.text.toString().equals("Studio")) "Login Successfull"
        else "Login Unsuccessfull"

        Toast.makeText(this,status,Toast.LENGTH_LONG).show()*/
    }
}