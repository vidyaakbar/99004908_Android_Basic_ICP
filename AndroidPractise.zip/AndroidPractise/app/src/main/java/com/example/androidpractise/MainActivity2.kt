package com.example.androidpractise

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.register.*

class MainActivity2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.register)


        button2.setOnClickListener {
            var u = editTextTextPersonName.text.toString()
            var e = editTextTextPersonName3.text.toString()
            var p = editTextTextPassword2.text.toString()
            Toast.makeText(this,"The register username is $u and email id is $e", Toast.LENGTH_LONG).show()
        }



    }
}